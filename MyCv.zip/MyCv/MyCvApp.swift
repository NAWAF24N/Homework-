
import SwiftUI

@main
struct MyCvApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
