
import SwiftUI

struct ContentView: View {
    
        var body: some View {
            TabView {
                HomeView()
                    .tabItem {
                        Label("cv", systemImage: "person.text.rectangle.fill")
                    }
                
                StoryView()
                    .tabItem {
                        Label("Story", systemImage: "book")
                    }
                
                SkillsView()
                    .tabItem {
                        Label("skills", systemImage: "star")
                    }
                
                Contact()
                    .tabItem {
                        Label("Contact", systemImage: "envelope.circle")
                    }
            }
            
        }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
