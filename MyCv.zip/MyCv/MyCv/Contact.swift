import SwiftUI

struct Contact: View {

    var body: some View {
        VStack {
            Text("Contact  Me")
                .font(.largeTitle)
                .fontWeight(.bold)
                .position(x : 180 , y: 50)

                        
            
            Image(systemName: "phone.bubble.left.fill")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .position(x: 110,y: -60)
                .padding(70)
            
            
            Link("i hoop to send me an email", destination: URL(string: "https://nawafabdulaziza@gmail.com")!
            )
                .padding()

            Text("Phone Number : 0595608612")
                .foregroundColor(Color.blue)
            
            
        }
        .padding()
    }
}

struct FunFactsView_Previews: PreviewProvider {
    static var previews: some View {
        Contact()
    }
}
