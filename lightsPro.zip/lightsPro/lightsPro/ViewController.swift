
import UIKit

class ViewController: UIViewController {


    @IBOutlet weak var lightStatus: UIButton!
    var turnOn = true
    override func viewDidLoad() {
        super.viewDidLoad()
        chengelight()
    }
    func chengelight() {
        if turnOn{
            lightStatus.setTitle("light On 💡", for: .normal)
            view.backgroundColor = .white
        }
        else{
            view.backgroundColor = .black
            lightStatus.setTitle("light off ⚫️", for: .normal)
        }
    }
    @IBAction func buttonPressed(_ sender: UIButton) {
        
        turnOn.toggle()
        chengelight()
    }
}

 


