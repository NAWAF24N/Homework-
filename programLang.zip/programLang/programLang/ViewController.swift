//
//  ViewController.swift
//  programLang
//
//  Created by  Abdullah on 15/07/1444 AH.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

