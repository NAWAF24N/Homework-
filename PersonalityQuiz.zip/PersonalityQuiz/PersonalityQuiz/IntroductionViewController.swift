//
//  SceneDelegate.swift
//  PersonalityQuiz
//
//  Created by  نواف عبدالعزيز on 01/22/1444 AH.
//
import UIKit

class IntroductionViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func unwindToQuizIntroduction(segue: UIStoryboardSegue){
        
    }


}

