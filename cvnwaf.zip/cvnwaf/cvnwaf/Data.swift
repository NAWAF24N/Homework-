

import Foundation
import SwiftUI

struct Info {
    let imag: String
    let name: String
    let story: String
    let skills: [String]
    let prog_langu: [String]
    let Facts: [String]
}

let information = Info(
    imag: "programing",
    name: "nawaf abdulaziz",
    story: "I am a student at Shaqra University in the College of Sciences and Humanities majoring in computer science with a bachelor’s degree. I am passionate about programming and have mastered many programming languages, and I have little experience in design ",
    skills: ["Works under pressure ", "problem solver ", "Typing fast"],
    prog_langu: ["swift", "java", "python"],
    Facts: [
        "student at Shaqra University",
        "majore in computer science",
        "Born in 2001",
        "I have mastered many programming languages",
    ]
)
