

import SwiftUI

struct SkillsView: View {
    var body: some View {
        VStack {
            Text("SKILLS")
                .font(.largeTitle)
                .fontWeight(.bold)
                .padding(.bottom, 40)
            
            Text("programming  languages")
                .font(.title2)
            

            
            HStack {
                ForEach(information.prog_langu, id: \.self) { hobby in Image(  hobby)
                        .resizable()
                        .frame(maxWidth:100, maxHeight: 100)
                    
                }
                .padding(20)
            }
            .padding()
            
            Text("work skills")
                .font(.title2)
            
            HStack(spacing: 60) {
                ForEach(information.skills, id: \.self) { sk in
                    Text(sk)
                        .font(.system(size: 20))
                        
                }
            }
            .padding()

            

            
        }
    }
}

struct FavoritesView_Previews: PreviewProvider {
    static var previews: some View {
        SkillsView()
    }
}
